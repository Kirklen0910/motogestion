<?php
require_once '../../config/database.php';
if (!isset($_SESSION['user_id'])) { 
    header('Location: /modules/auth/login.php'); 
    exit; 
}

$role = $_SESSION['role'] ?? 'seller';

// ===== OBTENER FILTRO DE GRÁFICA =====
$periodo = $_GET['periodo'] ?? '6meses';
$mes_especifico = $_GET['mes'] ?? date('Y-m');

// ===== CONSULTAS PRINCIPALES =====
$totalProducts = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$totalClients = $pdo->query("SELECT COUNT(*) FROM clients")->fetchColumn();
$totalSuppliers = $pdo->query("SELECT COUNT(*) FROM suppliers")->fetchColumn();

// Ventas hoy
$salesToday = $pdo->query("SELECT COALESCE(SUM(total),0) FROM sales WHERE DATE(sale_date)=CURDATE()")->fetchColumn();
$countSalesToday = $pdo->query("SELECT COUNT(*) FROM sales WHERE DATE(sale_date)=CURDATE()")->fetchColumn();

// Ventas mes
$salesMonth = $pdo->query("SELECT COALESCE(SUM(total),0) FROM sales WHERE MONTH(sale_date)=MONTH(CURDATE()) AND YEAR(sale_date)=YEAR(CURDATE())")->fetchColumn();
$profitMonth = $pdo->query("SELECT COALESCE(SUM(total_profit),0) FROM sales WHERE MONTH(sale_date)=MONTH(CURDATE()) AND YEAR(sale_date)=YEAR(CURDATE())")->fetchColumn();

// Stock
$lowStock = $pdo->query("SELECT COUNT(*) FROM products WHERE stock <= min_stock AND stock > 0")->fetchColumn();
$outOfStock = $pdo->query("SELECT COUNT(*) FROM products WHERE stock = 0")->fetchColumn();
$totalStock = $pdo->query("SELECT SUM(stock) FROM products")->fetchColumn();
$normalStock = $totalProducts - $lowStock - $outOfStock;

// Top Vendedores
$topSellers = $pdo->query("
    SELECT 
        u.username,
        u.fullname,
        COUNT(s.id) as total_ventas,
        COALESCE(SUM(s.total), 0) as total_vendido
    FROM sales s
    JOIN users u ON s.user_id = u.id
    WHERE MONTH(s.sale_date) = MONTH(CURDATE()) 
        AND YEAR(s.sale_date) = YEAR(CURDATE())
    GROUP BY s.user_id
    ORDER BY total_vendido DESC
    LIMIT 5
")->fetchAll();

// Rentabilidad por vendedor
$sellerProfit = $pdo->query("
    SELECT 
        u.username,
        u.fullname,
        COALESCE(SUM(s.total_profit), 0) as ganancia_total,
        COALESCE(SUM(s.total), 0) as venta_total,
        CASE 
            WHEN COALESCE(SUM(s.total), 0) > 0 
            THEN (COALESCE(SUM(s.total_profit), 0) / COALESCE(SUM(s.total), 0)) * 100 
            ELSE 0 
        END as margen_ganancia
    FROM sales s
    JOIN users u ON s.user_id = u.id
    WHERE MONTH(s.sale_date) = MONTH(CURDATE())
    GROUP BY s.user_id
    ORDER BY ganancia_total DESC
    LIMIT 5
")->fetchAll();

// Crecimiento vs mes anterior
$lastMonthSales = $pdo->query("
    SELECT COALESCE(SUM(total),0) FROM sales 
    WHERE MONTH(sale_date)=MONTH(CURDATE() - INTERVAL 1 MONTH) 
    AND YEAR(sale_date)=YEAR(CURDATE() - INTERVAL 1 MONTH)
")->fetchColumn();
$growthPercent = $lastMonthSales > 0 ? (($salesMonth - $lastMonthSales) / $lastMonthSales * 100) : 0;

// Meta diaria
$dailyGoal = 15000;
$goalPercent = $dailyGoal > 0 ? min(100, ($salesToday / $dailyGoal) * 100) : 0;

// Ventas por día
$salesByDay = $pdo->query("
    SELECT 
        DAYOFWEEK(sale_date) as dia_num,
        CASE DAYOFWEEK(sale_date)
            WHEN 1 THEN 'Domingo'
            WHEN 2 THEN 'Lunes'
            WHEN 3 THEN 'Martes'
            WHEN 4 THEN 'Miércoles'
            WHEN 5 THEN 'Jueves'
            WHEN 6 THEN 'Viernes'
            WHEN 7 THEN 'Sábado'
        END as dia_nombre,
        COUNT(*) as num_ventas,
        COALESCE(SUM(total), 0) as total_ventas
    FROM sales
    WHERE sale_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    GROUP BY dia_num
    ORDER BY dia_num
")->fetchAll();

// ===== DATOS PARA GRÁFICA CON FILTRO =====
$whereCondition = "";
switch($periodo) {
    case 'mes_actual':
        $whereCondition = "WHERE MONTH(sale_date) = MONTH(CURDATE()) AND YEAR(sale_date) = YEAR(CURDATE())";
        break;
    case '6meses':
        $whereCondition = "WHERE sale_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)";
        break;
    case '1ano':
        $whereCondition = "WHERE sale_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)";
        break;
    case 'mes_especifico':
        $whereCondition = "WHERE DATE_FORMAT(sale_date, '%Y-%m') = '$mes_especifico'";
        break;
    default:
        $whereCondition = "WHERE sale_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)";
}

$salesChart = $pdo->query("
    SELECT 
        DATE_FORMAT(sale_date, '%Y-%m') as mes,
        DATE_FORMAT(sale_date, '%M %Y') as mes_nombre,
        SUM(total) as total,
        COUNT(*) as num_ventas
    FROM sales 
    $whereCondition
    GROUP BY mes
    ORDER BY mes
")->fetchAll();

$labels = [];
$data = [];
$ventasCount = [];
foreach($salesChart as $row){
    $labels[] = $periodo == 'mes_especifico' ? $row['mes_nombre'] : $row['mes'];
    $data[] = floatval($row['total']);
    $ventasCount[] = $row['num_ventas'];
}

// Obtener lista de meses disponibles para el selector
$mesesDisponibles = $pdo->query("
    SELECT DISTINCT DATE_FORMAT(sale_date, '%Y-%m') as valor, 
           DATE_FORMAT(sale_date, '%M %Y') as nombre
    FROM sales 
    ORDER BY sale_date DESC
")->fetchAll();

// ===== CONSULTAS PARA CAJERO =====
$pendingCount = $pdo->query("SELECT COUNT(*) FROM sales WHERE status = 'pendiente'")->fetchColumn();
$totalPending = $pdo->query("SELECT COALESCE(SUM(total),0) FROM sales WHERE status = 'pendiente'")->fetchColumn();

include '../../includes/header.php';
?>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
    /* Estilos adicionales específicos del dashboard */
    .stat-card {
        border: none;
        border-radius: 20px;
        padding: 24px;
        background: white;
        box-shadow: 0 10px 40px rgba(102, 126, 234, 0.10);
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        overflow: hidden;
        height: 100%;
    }
    .stat-card::after {
        content: '';
        position: absolute;
        top: -50%;
        right: -50%;
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        opacity: 0.03;
        border-radius: 50%;
        transition: all 0.6s ease;
    }
    .stat-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 20px 60px rgba(102, 126, 234, 0.20);
    }
    .stat-card:hover::after {
        transform: scale(1.5);
        opacity: 0.08;
    }
    .stat-value {
        font-size: 32px;
        font-weight: 700;
        margin: 8px 0;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    .icon-circle {
        width: 54px;
        height: 54px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        transition: all 0.3s ease;
        flex-shrink: 0;
    }
    .icon-circle.bg-primary-light {
        background: rgba(102, 126, 234, 0.12);
        color: #667eea;
    }
    .icon-circle.bg-success-light {
        background: rgba(72, 187, 120, 0.12);
        color: #48bb78;
    }
    .icon-circle.bg-warning-light {
        background: rgba(237, 137, 54, 0.12);
        color: #ed8936;
    }
    .icon-circle.bg-danger-light {
        background: rgba(252, 129, 129, 0.12);
        color: #fc8181;
    }
    .icon-circle.bg-info-light {
        background: rgba(99, 179, 237, 0.12);
        color: #63b3ed;
    }
    .stat-card:hover .icon-circle {
        transform: scale(1.1) rotate(-5deg);
    }
    .progress-custom {
        height: 8px;
        border-radius: 10px;
        background: #edf2f7;
        overflow: hidden;
    }
    .progress-custom .progress-bar {
        background: linear-gradient(90deg, #667eea, #764ba2);
        border-radius: 10px;
        transition: width 1.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .percentage-circle {
        width: 130px;
        height: 130px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto;
        font-size: 32px;
        font-weight: 700;
        color: #2d3748;
        position: relative;
        transition: all 0.8s ease;
    }
    .percentage-circle::after {
        content: '';
        position: absolute;
        width: 90px;
        height: 90px;
        border-radius: 50%;
        background: white;
    }
    .percentage-circle span {
        position: relative;
        z-index: 1;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    .filter-btn {
        border-radius: 25px;
        padding: 8px 22px;
        margin: 0 4px;
        transition: all 0.3s ease;
        border: 2px solid #e2e8f0;
        background: white;
        color: #4a5568;
        font-weight: 500;
    }
    .filter-btn:hover {
        transform: translateY(-2px);
        border-color: #667eea;
        color: #667eea;
    }
    .filter-btn.active {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-color: transparent;
        box-shadow: 0 8px 20px rgba(102, 126, 234, 0.35);
    }
    .filter-btn.active:hover {
        transform: translateY(-2px);
        box-shadow: 0 12px 30px rgba(102, 126, 234, 0.45);
    }
    .btn-quick {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        font-weight: 600;
        border-radius: 15px;
        padding: 18px 12px;
        border: none;
        position: relative;
        overflow: hidden;
    }
    .btn-quick::after {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        width: 0;
        height: 0;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.2);
        transition: all 0.6s ease;
        transform: translate(-50%, -50%);
    }
    .btn-quick:hover::after {
        width: 300px;
        height: 300px;
    }
    .btn-quick:hover {
        transform: translateY(-4px) scale(1.03);
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
    }
    .btn-quick i {
        font-size: 28px;
        display: block;
        margin-bottom: 6px;
    }
    .btn-quick-primary {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
    }
    .btn-quick-primary:hover { color: white; }
    .btn-quick-success {
        background: linear-gradient(135deg, #48bb78, #38a169);
        color: white;
    }
    .btn-quick-success:hover { color: white; }
    .btn-quick-warning {
        background: linear-gradient(135deg, #ed8936, #dd6b20);
        color: white;
    }
    .btn-quick-warning:hover { color: white; }
    .btn-quick-info {
        background: linear-gradient(135deg, #63b3ed, #4299e1);
        color: white;
    }
    .btn-quick-info:hover { color: white; }
    .btn-quick-dark {
        background: linear-gradient(135deg, #4a5568, #2d3748);
        color: white;
    }
    .btn-quick-dark:hover { color: white; }
    .btn-quick-danger {
        background: linear-gradient(135deg, #fc8181, #e53e3e);
        color: white;
    }
    .btn-quick-danger:hover { color: white; }
    .btn-quick-secondary {
        background: linear-gradient(135deg, #a0aec0, #718096);
        color: white;
    }
    .btn-quick-secondary:hover { color: white; }
    
    .modern-card {
        border: none;
        border-radius: 20px;
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        box-shadow: 0 10px 40px rgba(102, 126, 234, 0.10);
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        overflow: hidden;
    }
    .modern-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 20px 60px rgba(102, 126, 234, 0.20);
    }
    .quick-access-card {
        background: rgba(255, 255, 255, 0.85);
        backdrop-filter: blur(20px);
        border-radius: 20px;
        padding: 24px;
        margin-bottom: 30px;
        box-shadow: 0 10px 40px rgba(102, 126, 234, 0.10);
        border: 1px solid rgba(255, 255, 255, 0.3);
    }
    .quick-access-card h5 {
        color: #2d3748;
        font-weight: 600;
    }
    .welcome-banner {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 20px;
        padding: 32px 40px;
        color: white;
        margin-bottom: 30px;
        position: relative;
        overflow: hidden;
    }
    .welcome-banner::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -20%;
        width: 400px;
        height: 400px;
        background: rgba(255, 255, 255, 0.05);
        border-radius: 50%;
    }
    .welcome-banner::after {
        content: '';
        position: absolute;
        bottom: -60%;
        left: -10%;
        width: 300px;
        height: 300px;
        background: rgba(255, 255, 255, 0.03);
        border-radius: 50%;
    }
    .welcome-banner h2 {
        font-weight: 700;
        position: relative;
        z-index: 1;
    }
    .welcome-banner p {
        opacity: 0.9;
        position: relative;
        z-index: 1;
    }
    .welcome-banner .fa-chart-line {
        opacity: 0.3;
        position: relative;
        z-index: 1;
    }
    @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
    }
    .animate-fadeInUp {
        animation: fadeInUp 0.6s ease forwards;
    }
    .animate-fadeInUp:nth-child(2) { animation-delay: 0.1s; }
    .animate-fadeInUp:nth-child(3) { animation-delay: 0.2s; }
    .animate-fadeInUp:nth-child(4) { animation-delay: 0.3s; }
</style>

<div class="container-fluid mt-4">

<!-- BIENVENIDA MEJORADA -->
<div class="welcome-banner">
    <div class="row align-items-center">
        <div class="col-md-8">
            <h2><i class="fas fa-wave-square"></i> ¡Bienvenido, <?= htmlspecialchars($_SESSION['fullname'] ?? $_SESSION['username']) ?>!</h2>
            <p class="mb-0">
                <i class="fas fa-user-tag"></i> Rol: <strong><?= ucfirst($role) ?></strong> &nbsp;|&nbsp;
                <i class="fas fa-calendar"></i> <?= date('l, d F Y') ?>
            </p>
        </div>
        <div class="col-md-4 text-end">
            <i class="fas fa-chart-line" style="font-size: 60px; opacity: 0.4;"></i>
        </div>
    </div>
</div>

<!-- ================= ACCESOS RÁPIDOS MEJORADOS ================= -->
<div class="quick-access-card">
    <h5 class="mb-3"><i class="fas fa-bolt" style="color: #667eea;"></i> Accesos Rápidos</h5>
    <div class="row g-3">
        
        <!-- VENDEDOR: Nueva Venta -->
        <?php if (in_array($role, ['seller', 'admin', 'superadmin'])): ?>
        <div class="col-md-3 col-6">
            <a href="/modules/sales/index.php" class="btn btn-quick btn-quick-primary w-100 py-3 rounded-4">
                <i class="fas fa-shopping-cart"></i>
                Nueva Venta
            </a>
        </div>
        <?php endif; ?>
        
        <!-- CAJERO: Cobros Pendientes -->
        <?php if (in_array($role, ['cashier', 'admin', 'superadmin'])): ?>
        <div class="col-md-3 col-6 position-relative">
            <a href="/modules/sales/pending.php" class="btn btn-quick btn-quick-warning w-100 py-3 rounded-4">
                <i class="fas fa-clock"></i>
                Cobros Pendientes
                <?php if ($pendingCount > 0): ?>
                    <span class="badge bg-danger text-white position-absolute top-0 start-100 translate-middle" style="font-size: 14px; padding: 6px 12px; border-radius: 20px;">
                        <?= $pendingCount ?>
                    </span>
                <?php endif; ?>
            </a>
        </div>
        <?php endif; ?>
        
        <!-- CAJERO y VENDEDOR: Historial de Ventas -->
        <?php if (in_array($role, ['seller', 'cashier', 'admin', 'superadmin'])): ?>
        <div class="col-md-3 col-6">
            <a href="/modules/sales/invoices.php" class="btn btn-quick btn-quick-info w-100 py-3 rounded-4">
                <i class="fas fa-file-invoice"></i>
                Historial de Ventas
            </a>
        </div>
        <?php endif; ?>
        
        <!-- INVENTARIO: Productos -->
        <?php if (in_array($role, ['inventory', 'admin', 'superadmin'])): ?>
        <div class="col-md-3 col-6">
            <a href="/modules/products/index.php" class="btn btn-quick btn-quick-success w-100 py-3 rounded-4">
                <i class="fas fa-box"></i>
                Productos
            </a>
        </div>
        <?php endif; ?>
        
        <!-- INVENTARIO/ADMIN: Proveedores -->
        <?php if (in_array($role, ['inventory', 'admin', 'superadmin'])): ?>
        <div class="col-md-3 col-6">
            <a href="/modules/suppliers/index.php" class="btn btn-quick btn-quick-secondary w-100 py-3 rounded-4">
                <i class="fas fa-truck"></i>
                Proveedores
            </a>
        </div>
        <?php endif; ?>
        
        <!-- CLIENTES - Todos excepto finance -->
        <?php if ($role != 'finance'): ?>
        <div class="col-md-3 col-6">
            <a href="/modules/clients/index.php" class="btn btn-quick btn-quick-info w-100 py-3 rounded-4">
                <i class="fas fa-users"></i>
                Clientes
            </a>
        </div>
        <?php endif; ?>
        
        <!-- REPORTES - Todos los roles -->
        <?php if (in_array($role, ['seller', 'cashier', 'inventory', 'finance', 'admin', 'superadmin'])): ?>
        <div class="col-md-3 col-6">
            <a href="/modules/reports/index.php" class="btn btn-quick btn-quick-dark w-100 py-3 rounded-4">
                <i class="fas fa-chart-line"></i>
                Reportes
            </a>
        </div>
        <?php endif; ?>

        <!-- USUARIOS - Solo admin y superadmin -->
        <?php if (in_array($role, ['admin', 'superadmin'])): ?>
        <div class="col-md-3 col-6">
            <a href="/modules/auth/register.php" class="btn btn-quick btn-quick-danger w-100 py-3 rounded-4">
                <i class="fas fa-user-shield"></i>
                Usuarios
            </a>
        </div>
        <?php endif; ?>
        
    </div>
</div>

<!-- ================= CARDS POR ROL ================= -->

<!-- INVENTARIO -->
<?php if (in_array($role, ['inventory', 'admin', 'superadmin'])): ?>
<div class="row mb-4">
    <div class="col-md-3 animate-fadeInUp">
        <div class="stat-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">Total Productos</small>
                    <div class="stat-value"><?= number_format($totalProducts) ?></div>
                </div>
                <div class="icon-circle bg-primary-light">
                    <i class="fas fa-box"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 animate-fadeInUp">
        <div class="stat-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">Stock Actual</small>
                    <div class="stat-value"><?= number_format($totalStock) ?></div>
                </div>
                <div class="icon-circle bg-success-light">
                    <i class="fas fa-cubes"></i>
                </div>
            </div>
            <?php $stockHealthPercent = $totalProducts > 0 ? (($totalProducts - $lowStock) / $totalProducts * 100) : 100; ?>
            <div class="mt-2">
                <small>Salud: <?= number_format($stockHealthPercent,1) ?>%</small>
                <div class="progress-custom">
                    <div class="progress-bar" style="width: <?= $stockHealthPercent ?>%"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 animate-fadeInUp">
        <div class="stat-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">Stock Bajo</small>
                    <div class="stat-value" style="color: #ed8936; -webkit-text-fill-color: #ed8936;"><?= $lowStock ?></div>
                </div>
                <div class="icon-circle bg-warning-light">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 animate-fadeInUp">
        <div class="stat-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">Sin Stock</small>
                    <div class="stat-value" style="color: #fc8181; -webkit-text-fill-color: #fc8181;"><?= $outOfStock ?></div>
                </div>
                <div class="icon-circle bg-danger-light">
                    <i class="fas fa-times-circle"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Doughnut Inventario -->
<div class="row mb-4">
    <div class="col-md-6">
        <div class="modern-card shadow-sm">
            <div class="card-header bg-white border-0 pt-4">
                <h5 class="mb-0"><i class="fas fa-chart-pie" style="color: #ed8936;"></i> Estado del Inventario</h5>
            </div>
            <div class="card-body">
                <canvas id="inventoryDoughnut" style="max-height: 300px;"></canvas>
                <div class="row mt-3 text-center">
                    <div class="col-4">
                        <small class="text-muted">Normal</small>
                        <h6 class="text-success"><?= $normalStock ?></h6>
                    </div>
                    <div class="col-4">
                        <small class="text-muted">Bajo</small>
                        <h6 class="text-warning"><?= $lowStock ?></h6>
                    </div>
                    <div class="col-4">
                        <small class="text-muted">Sin Stock</small>
                        <h6 class="text-danger"><?= $outOfStock ?></h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- VENTAS/CAJA -->
<?php if (in_array($role, ['seller', 'cashier', 'admin', 'superadmin'])): ?>
<div class="row mb-4">
    <div class="col-md-4 animate-fadeInUp">
        <div class="stat-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">Ventas Hoy</small>
                    <div class="stat-value" style="color: #48bb78; -webkit-text-fill-color: #48bb78;">L <?= number_format($salesToday,2) ?></div>
                    <small class="text-muted"><?= $countSalesToday ?> transacciones</small>
                </div>
                <div class="icon-circle bg-success-light">
                    <i class="fas fa-shopping-cart"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4 animate-fadeInUp">
        <div class="stat-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">Clientes</small>
                    <div class="stat-value"><?= number_format($totalClients) ?></div>
                </div>
                <div class="icon-circle bg-info-light">
                    <i class="fas fa-users"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4 animate-fadeInUp">
        <div class="stat-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">Ticket Promedio</small>
                    <div class="stat-value">L <?= number_format($countSalesToday > 0 ? $salesToday/$countSalesToday : 0,2) ?></div>
                </div>
                <div class="icon-circle bg-primary-light">
                    <i class="fas fa-receipt"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Anillo Meta y Ventas por Día -->
<div class="row mb-4">
    <div class="col-md-6">
        <div class="modern-card shadow-sm">
            <div class="card-header bg-white border-0 pt-4">
                <h5 class="mb-0"><i class="fas fa-bullseye" style="color: #48bb78;"></i> Meta Diaria</h5>
            </div>
            <div class="card-body text-center">
                <div class="percentage-circle" style="background: conic-gradient(#667eea <?= $goalPercent ?>%, #edf2f7 0%);">
                    <span><?= number_format($goalPercent,0) ?>%</span>
                </div>
                <p class="mt-3">
                    <strong>L <?= number_format($salesToday,2) ?></strong> de L <?= number_format($dailyGoal,2) ?>
                </p>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="modern-card shadow-sm">
            <div class="card-header bg-white border-0 pt-4">
                <h5 class="mb-0"><i class="fas fa-chart-line" style="color: #667eea;"></i> Ventas por Día</h5>
            </div>
            <div class="card-body">
                <canvas id="weeklySalesChart" style="max-height: 250px;"></canvas>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ================= CAJERO - COBROS PENDIENTES ================= -->
<?php if (in_array($role, ['cashier', 'admin', 'superadmin'])): ?>
<div class="row mb-4">
    <div class="col-md-6 animate-fadeInUp">
        <div class="stat-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">Ventas Pendientes de Cobro</small>
                    <div class="stat-value" style="color: #ed8936; -webkit-text-fill-color: #ed8936;"><?= number_format($pendingCount) ?></div>
                    <small class="text-muted">Esperando pago del cajero</small>
                </div>
                <div class="icon-circle bg-warning-light">
                    <i class="fas fa-clock"></i>
                </div>
            </div>
            <div class="mt-2">
                <a href="/modules/sales/pending.php" class="btn btn-quick btn-quick-warning w-100 py-2 rounded-4" style="font-size: 14px;">
                    <i class="fas fa-money-bill"></i> Ver Cobros Pendientes
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-6 animate-fadeInUp">
        <div class="stat-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">Total por Cobrar</small>
                    <div class="stat-value" style="color: #fc8181; -webkit-text-fill-color: #fc8181;">L <?= number_format($totalPending, 2) ?></div>
                    <small class="text-muted">Monto total en ventas pendientes</small>
                </div>
                <div class="icon-circle bg-danger-light">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- FINANZAS -->
<?php if (in_array($role, ['finance', 'admin', 'superadmin'])): ?>
<div class="row mb-4">
    <div class="col-md-4 animate-fadeInUp">
        <div class="stat-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">Ventas del Mes</small>
                    <div class="stat-value">L <?= number_format($salesMonth,2) ?></div>
                </div>
                <div class="icon-circle bg-primary-light">
                    <i class="fas fa-chart-line"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4 animate-fadeInUp">
        <div class="stat-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">Ganancia del Mes</small>
                    <div class="stat-value" style="color: #48bb78; -webkit-text-fill-color: #48bb78;">L <?= number_format($profitMonth,2) ?></div>
                </div>
                <div class="icon-circle bg-success-light">
                    <i class="fas fa-dollar-sign"></i>
                </div>
            </div>
            <?php $profitPercent = $salesMonth > 0 ? ($profitMonth / $salesMonth * 100) : 0; ?>
            <div class="mt-2">
                <small>Margen: <strong><?= number_format($profitPercent,1) ?>%</strong></small>
                <div class="progress-custom">
                    <div class="progress-bar" style="width: <?= min(100, $profitPercent) ?>%"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4 animate-fadeInUp">
        <div class="stat-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">Crecimiento</small>
                    <div class="stat-value <?= $growthPercent >= 0 ? 'text-success' : 'text-danger' ?>" style="<?= $growthPercent >= 0 ? 'color:#48bb78;-webkit-text-fill-color:#48bb78;' : 'color:#fc8181;-webkit-text-fill-color:#fc8181;' ?>">
                        <?= $growthPercent >= 0 ? '+' : '' ?><?= number_format($growthPercent,1) ?>%
                    </div>
                </div>
                <div class="icon-circle bg-info-light">
                    <i class="fas fa-arrow-<?= $growthPercent >= 0 ? 'up' : 'down' ?>"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ================= GRÁFICA PRINCIPAL CON FILTROS ================= -->
<div class="modern-card mb-4 shadow-sm">
    <div class="card-header bg-white border-0 pt-4 pb-0">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h5 class="mb-0"><i class="fas fa-chart-bar" style="color: #667eea;"></i> Evolución de Ventas</h5>
                <small class="text-muted">Visualiza tus ventas en diferentes períodos</small>
            </div>
            <div class="col-md-6">
                <div class="btn-group float-md-end mt-2 mt-md-0 flex-wrap" role="group">
                    <a href="?periodo=mes_actual" class="btn filter-btn <?= $periodo == 'mes_actual' ? 'active' : '' ?>">
                        <i class="fas fa-calendar-month"></i> Mes Actual
                    </a>
                    <a href="?periodo=6meses" class="btn filter-btn <?= $periodo == '6meses' ? 'active' : '' ?>">
                        <i class="fas fa-chart-line"></i> 6 Meses
                    </a>
                    <a href="?periodo=1ano" class="btn filter-btn <?= $periodo == '1ano' ? 'active' : '' ?>">
                        <i class="fas fa-calendar-year"></i> 1 Año
                    </a>
                    
                    <!-- Selector de mes específico -->
                    <div class="dropdown d-inline-block ms-2">
                        <button class="btn filter-btn dropdown-toggle" type="button" data-bs-toggle="dropdown">
                            <i class="fas fa-calendar-alt"></i> Mes Específico
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php foreach ($mesesDisponibles as $mes): ?>
                            <li>
                                <a class="dropdown-item" href="?periodo=mes_especifico&mes=<?= $mes['valor'] ?>">
                                    <?= $mes['nombre'] ?>
                                </a>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body">
        <?php if (empty($labels)): ?>
            <div class="alert alert-info text-center">
                <i class="fas fa-info-circle"></i> No hay datos de ventas para el período seleccionado.
            </div>
        <?php else: ?>
            <canvas id="salesChart" style="max-height: 400px;"></canvas>
            
            <!-- Resumen del período -->
            <div class="row mt-4 pt-3 border-top">
                <div class="col-md-4 text-center">
                    <small class="text-muted">Total Ventas</small>
                    <h4 class="text-primary" style="color: #667eea;">L <?= number_format(array_sum($data), 2) ?></h4>
                </div>
                <div class="col-md-4 text-center">
                    <small class="text-muted">Promedio por Período</small>
                    <h4 class="text-success" style="color: #48bb78;">L <?= number_format(count($data) > 0 ? array_sum($data) / count($data) : 0, 2) ?></h4>
                </div>
                <div class="col-md-4 text-center">
                    <small class="text-muted">Total Transacciones</small>
                    <h4 class="text-info" style="color: #63b3ed;"><?= number_format(array_sum($ventasCount)) ?></h4>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Top Vendedores -->
<div class="row mb-4">
    <div class="col-md-6">
        <div class="modern-card shadow-sm">
            <div class="card-header bg-white border-0 pt-4">
                <h5 class="mb-0"><i class="fas fa-trophy" style="color: #ed8936;"></i> Top Vendedores del Mes</h5>
            </div>
            <div class="card-body">
                <?php if (count($topSellers) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Vendedor</th>
                                    <th>Ventas</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($topSellers as $index => $seller): ?>
                                <tr>
                                    <td><span class="badge bg-warning"><?= $index + 1 ?></span></td>
                                    <td><strong><?= htmlspecialchars($seller['fullname'] ?? $seller['username']) ?></strong></td>
                                    <td><?= $seller['total_ventas'] ?></td>
                                    <td class="text-success">L <?= number_format($seller['total_vendido'], 2) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted text-center">Sin ventas este mes</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="modern-card shadow-sm">
            <div class="card-header bg-white border-0 pt-4">
                <h5 class="mb-0"><i class="fas fa-chart-simple" style="color: #63b3ed;"></i> Rentabilidad por Vendedor</h5>
            </div>
            <div class="card-body">
                <?php if (count($sellerProfit) > 0): ?>
                    <?php foreach ($sellerProfit as $seller): ?>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between">
                                <span><strong><?= htmlspecialchars($seller['fullname'] ?? $seller['username']) ?></strong></span>
                                <span class="text-success">L <?= number_format($seller['ganancia_total'], 2) ?></span>
                            </div>
                            <div class="progress-custom" style="height: 20px;">
                                <div class="progress-bar" style="width: <?= min(100, $seller['margen_ganancia']) ?>%; background: linear-gradient(90deg, #667eea, #764ba2);">
                                    <?= number_format($seller['margen_ganancia'], 1) ?>%
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-muted text-center">Sin datos de rentabilidad</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

</div>

<script>
<?php if (in_array($role, ['finance', 'admin', 'superadmin']) && !empty($labels)): ?>
const ctx = document.getElementById('salesChart');
if(ctx){
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?= json_encode($labels) ?>,
            datasets: [{
                label: 'Ventas (Lempiras)',
                data: <?= json_encode($data) ?>,
                backgroundColor: 'rgba(102, 126, 234, 0.7)',
                borderColor: 'rgba(102, 126, 234, 1)',
                borderWidth: 2,
                borderRadius: 10,
                barPercentage: 0.6,
                categoryPercentage: 0.8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        font: { weight: 'bold' }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(45, 55, 72, 0.9)',
                    titleColor: '#fff',
                    bodyColor: '#667eea',
                    callbacks: {
                        label: function(context) {
                            return 'Total: L ' + context.parsed.y.toFixed(2);
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0,0,0,0.05)'
                    },
                    ticks: {
                        callback: function(value) {
                            return 'L ' + value.toFixed(2);
                        }
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
}
<?php endif; ?>

<?php if (in_array($role, ['inventory', 'admin', 'superadmin'])): ?>
const inventoryCtx = document.getElementById('inventoryDoughnut');
if(inventoryCtx){
    new Chart(inventoryCtx, {
        type: 'doughnut',
        data: {
            labels: ['Stock Normal (<?= $normalStock ?>)', 'Stock Bajo (<?= $lowStock ?>)', 'Sin Stock (<?= $outOfStock ?>)'],
            datasets: [{
                data: [<?= $normalStock ?>, <?= $lowStock ?>, <?= $outOfStock ?>],
                backgroundColor: ['#48bb78', '#ed8936', '#fc8181'],
                borderWidth: 0,
                cutout: '60%'
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });
}
<?php endif; ?>

<?php if (in_array($role, ['seller', 'cashier', 'admin', 'superadmin']) && !empty($salesByDay)): ?>
const weeklyCtx = document.getElementById('weeklySalesChart');
if(weeklyCtx){
    new Chart(weeklyCtx, {
        type: 'line',
        data: {
            labels: <?= json_encode(array_column($salesByDay, 'dia_nombre')) ?>,
            datasets: [{
                label: 'Ventas (Lempiras)',
                data: <?= json_encode(array_column($salesByDay, 'total_ventas')) ?>,
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#667eea',
                pointBorderColor: '#fff',
                pointRadius: 5,
                pointHoverRadius: 7
            }]
        },
        options: {
            responsive: true,
            plugins: {
                tooltip: {
                    backgroundColor: 'rgba(45, 55, 72, 0.9)',
                    callbacks: {
                        label: function(context) {
                            return 'L ' + context.parsed.y.toFixed(2);
                        }
                    }
                }
            }
        }
    });
}
<?php endif; ?>
</script>

<?php include '../../includes/footer.php'; ?>