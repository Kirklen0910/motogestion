<?php
require_once '../../config/database.php';
if (!isset($_SESSION['user_id'])) { 
    header('Location: /modules/auth/login.php'); 
    exit; 
}

$clients = $pdo->query("SELECT * FROM clients ORDER BY name")->fetchAll();
$products = $pdo->query("SELECT * FROM products WHERE stock > 0 ORDER BY name")->fetchAll();

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<style>
    .product-option {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .product-option img {
        width: 40px;
        height: 40px;
        object-fit: cover;
        border-radius: 8px;
    }
    .cart-product-img {
        width: 40px;
        height: 40px;
        object-fit: cover;
        border-radius: 8px;
    }
    .product-img-select {
        width: 40px;
        height: 40px;
        object-fit: cover;
        border-radius: 8px;
        margin-right: 10px;
        vertical-align: middle;
    }
    .select-product-option {
        display: flex;
        align-items: center;
        padding: 5px;
    }
    .custom-select-wrapper {
        position: relative;
        cursor: pointer;
    }
    .custom-select-trigger {
        background: white;
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: pointer;
    }
    .custom-select-trigger .arrow {
        transition: transform 0.2s;
    }
    .custom-options {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: white;
        border: 1px solid #ddd;
        border-radius: 5px;
        z-index: 1000;
        margin-top: 5px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        max-height: 300px;
        overflow-y: auto;
    }
    .custom-option {
        padding: 8px 12px;
        cursor: pointer;
        border-bottom: 1px solid #eee;
    }
    .custom-option:hover {
        background-color: #f5f5f5;
    }
    .custom-option:last-child {
        border-bottom: none;
    }
    .cliente-generico {
        background-color: #e8f5e9;
        border-left: 4px solid #4caf50;
        font-weight: bold;
    }
</style>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-5">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5><i class="fas fa-shopping-cart"></i> Punto de Venta</h5>
                </div>
                <div class="card-body">
                    <!-- Selección de Cliente -->
                    <h6><i class="fas fa-user"></i> Cliente</h6>
                    <select id="client_id" class="form-control mb-3">
                        <option value="">-- Seleccionar Cliente --</option>
                        <!-- Cliente Genérico al inicio -->
                        <option value="0" class="cliente-generico">🏪 CLIENTE GENÉRICO (Venta sin identificación)</option>
                        <option disabled>──────────</option>
                        <?php foreach ($clients as $c): ?>
                            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    
                    <hr>
                    
                    <!-- Selección de Producto con Imagen -->
                    <h6><i class="fas fa-box"></i> Agregar Producto</h6>
                    
                    <div class="mb-2">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="productImagePreview">
                                    <i class="fas fa-image"></i>
                                </span>
                            </div>
                            <div id="customSelect" class="custom-select-wrapper w-100">
                                <div class="custom-select-trigger form-control" onclick="toggleCustomSelect()">
                                    <span id="selectedProductText">-- Seleccionar Producto --</span>
                                    <span class="arrow">▼</span>
                                </div>
                                <div class="custom-options" id="customOptions" style="display: none;">
                                    <?php foreach ($products as $p): 
                                        $hasImage = !empty($p['image']) && file_exists('../../' . $p['image']);
                                    ?>
                                        <div class="custom-option" data-value="<?= $p['id'] ?>" 
                                             data-price="<?= $p['price'] ?>" 
                                             data-name="<?= htmlspecialchars($p['name']) ?>" 
                                             data-stock="<?= $p['stock'] ?>"
                                             data-code="<?= htmlspecialchars($p['code']) ?>"
                                             data-image="<?= $hasImage ? '/'.$p['image'] : '' ?>"
                                             onclick="selectProduct(this)">
                                            <div class="select-product-option">
                                                <?php if ($hasImage): ?>
                                                    <img src="/<?= $p['image'] ?>" class="product-img-select" alt="<?= htmlspecialchars($p['name']) ?>">
                                                <?php else: ?>
                                                    <div style="width:40px;height:40px;background:#f0f0f0;border-radius:8px;display:inline-flex;align-items:center;justify-content:center;margin-right:10px;">
                                                        <i class="fas fa-image" style="color:#999;"></i>
                                                    </div>
                                                <?php endif; ?>
                                                <div>
                                                    <strong><?= htmlspecialchars($p['name']) ?></strong><br>
                                                    <small class="text-muted">L <?= number_format($p['price'],2) ?> | Stock: <?= $p['stock'] ?> | Cód: <?= htmlspecialchars($p['code']) ?></small>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-2">
                        <label>Cantidad</label>
                        <input type="number" id="quantity" placeholder="Cantidad" class="form-control" min="1">
                        <small id="stock_warning" class="text-danger" style="display:none;"></small>
                        <button id="add_to_cart" class="btn btn-primary mt-2 w-100">
                            <i class="fas fa-plus-circle"></i> Agregar al Carrito
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-7">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h5><i class="fas fa-shopping-cart"></i> Carrito de Compras</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm" id="cart_table">
                            <thead class="table-dark">
                                <tr>
                                    <th>Imagen</th>
                                    <th>Producto</th>
                                    <th>Cant</th>
                                    <th>Stock Disp.</th>
                                    <th>Precio</th>
                                    <th>Subtotal</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="cart_body">
                                <tr><td colspan="7" class="text-center text-muted">Carrito vacío</td></tr>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="5" class="text-end"><strong>Total:</strong></td>
                                    <td><strong id="cart_total">0.00</strong></td>
                                    <td></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <button id="process_sale" class="btn btn-success w-100" disabled>
                        <i class="fas fa-check-circle"></i> Finalizar Venta
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Variables para el select personalizado
let selectedProduct = null;
let cart = [];

function toggleCustomSelect() {
    let options = document.getElementById('customOptions');
    if (options.style.display === 'none') {
        options.style.display = 'block';
    } else {
        options.style.display = 'none';
    }
}

function selectProduct(element) {
    let productId = element.dataset.value;
    let productName = element.dataset.name;
    let productPrice = parseFloat(element.dataset.price);
    let productStock = parseInt(element.dataset.stock);
    let productCode = element.dataset.code;
    let productImage = element.dataset.image;
    
    selectedProduct = {
        id: productId,
        name: productName,
        price: productPrice,
        stock: productStock,
        code: productCode,
        image: productImage
    };
    
    let imageHtml = productImage ? `<img src="${productImage}" style="width:30px;height:30px;border-radius:5px;margin-right:8px;">` : '<i class="fas fa-image" style="margin-right:8px;"></i>';
    document.getElementById('selectedProductText').innerHTML = imageHtml + productName + ' - L ' + productPrice.toFixed(2);
    
    if (productImage) {
        document.getElementById('productImagePreview').innerHTML = `<img src="${productImage}" style="width:30px;height:30px;border-radius:5px;">`;
    } else {
        document.getElementById('productImagePreview').innerHTML = '<i class="fas fa-image"></i>';
    }
    
    let quantityInput = document.getElementById('quantity');
    quantityInput.max = productStock;
    quantityInput.placeholder = `Cantidad (máx ${productStock})`;
    quantityInput.value = '';
    quantityInput.focus();
    
    document.getElementById('customOptions').style.display = 'none';
    validateQuantity();
}

// Cerrar dropdown al hacer clic fuera
document.addEventListener('click', function(event) {
    let wrapper = document.querySelector('.custom-select-wrapper');
    if (wrapper && !wrapper.contains(event.target)) {
        document.getElementById('customOptions').style.display = 'none';
    }
});

function validateQuantity() {
    let qty = parseInt(document.getElementById('quantity').value) || 0;
    let stock = selectedProduct ? selectedProduct.stock : 0;
    let stockWarning = document.getElementById('stock_warning');
    let addButton = document.getElementById('add_to_cart');
    
    if (!selectedProduct) {
        stockWarning.style.display = 'block';
        stockWarning.innerHTML = '⚠️ Seleccione un producto primero';
        addButton.disabled = true;
        return false;
    }
    
    if (qty > stock) {
        stockWarning.style.display = 'block';
        stockWarning.innerHTML = `⚠️ La cantidad (${qty}) excede el stock disponible (${stock})`;
        addButton.disabled = true;
        return false;
    } else if (qty <= 0) {
        stockWarning.style.display = 'block';
        stockWarning.innerHTML = `⚠️ La cantidad debe ser mayor a 0`;
        addButton.disabled = true;
        return false;
    } else {
        stockWarning.style.display = 'none';
        addButton.disabled = false;
        return true;
    }
}

document.getElementById('quantity').addEventListener('input', function() {
    validateQuantity();
});

document.getElementById('quantity').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        document.getElementById('add_to_cart').click();
    }
});

function updateCart() {
    let tbody = document.querySelector('#cart_body');
    tbody.innerHTML = '';
    let total = 0;
    
    if (cart.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">Carrito vacío</td></tr>';
        document.getElementById('cart_total').innerText = '0.00';
        document.getElementById('process_sale').disabled = true;
        return;
    }
    
    cart.forEach((item, idx) => {
        total += item.subtotal;
        tbody.innerHTML += `
            <tr>
                <td class="text-center">
                    ${item.image ? `<img src="${item.image}" class="cart-product-img">` : '<div style="width:40px;height:40px;background:#f0f0f0;border-radius:8px;display:flex;align-items:center;justify-content:center;"><i class="fas fa-image"></i></div>'}
                </td>
                <td><strong>${item.name}</strong><br><small class="text-muted">Cód: ${item.code}</small></td>
                <td>${item.qty}</td>
                <td>${item.stock}</td>
                <td>L ${item.price.toFixed(2)}</td>
                <td>L ${item.subtotal.toFixed(2)}</td>
                <td><button onclick="removeFromCart(${idx})" class="btn btn-sm btn-danger">X</button></td>
            </tr>
        `;
    });
    
    document.getElementById('cart_total').innerText = total.toFixed(2);
    document.getElementById('process_sale').disabled = false;
}

window.removeFromCart = function(idx) {
    cart.splice(idx, 1);
    updateCart();
};

document.getElementById('add_to_cart').addEventListener('click', function() {
    if (!selectedProduct) {
        alert('Seleccione un producto');
        return;
    }
    
    let qty = parseInt(document.getElementById('quantity').value);
    if (isNaN(qty) || qty < 1) {
        alert('Ingrese una cantidad válida');
        return;
    }
    
    if (!validateQuantity()) {
        return;
    }
    
    // Verificar si el producto ya está en el carrito
    let existingItem = cart.find(item => item.product_id == selectedProduct.id);
    if (existingItem) {
        let newQty = existingItem.qty + qty;
        if (newQty > selectedProduct.stock) {
            alert(`No puedes agregar más. Stock disponible: ${selectedProduct.stock}, ya tienes ${existingItem.qty} en el carrito.`);
            return;
        }
        existingItem.qty = newQty;
        existingItem.subtotal = existingItem.qty * existingItem.price;
    } else {
        cart.push({ 
            product_id: parseInt(selectedProduct.id),
            name: selectedProduct.name,
            code: selectedProduct.code,
            qty: qty, 
            price: selectedProduct.price, 
            stock: selectedProduct.stock,
            image: selectedProduct.image,
            subtotal: qty * selectedProduct.price 
        });
    }
    
    updateCart();
    document.getElementById('quantity').value = '';
    selectedProduct = null;
    document.getElementById('selectedProductText').innerHTML = '-- Seleccionar Producto --';
    document.getElementById('productImagePreview').innerHTML = '<i class="fas fa-image"></i>';
    document.getElementById('stock_warning').style.display = 'none';
    document.getElementById('add_to_cart').disabled = true;
    document.getElementById('quantity').placeholder = 'Cantidad';
});

document.getElementById('process_sale').addEventListener('click', function() {
    let clientId = document.getElementById('client_id').value;
    
    if (cart.length === 0) {
        alert('Carrito vacío');
        return;
    }
    
    if (!clientId) {
        alert('Seleccione un cliente');
        return;
    }
    
    // Deshabilitar botón para evitar doble envío
    this.disabled = true;
    this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Procesando...';
    
    // Enviar datos al servidor
    fetch('process_sale.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            client_id: clientId, 
            cart: cart.map(item => ({
                product_id: item.product_id,
                qty: item.qty,
                name: item.name,
                price: item.price
            }))
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert('✅ Venta registrada exitosamente');
            location.reload();
        } else {
            alert('❌ Error: ' + data.error);
            document.getElementById('process_sale').disabled = false;
            document.getElementById('process_sale').innerHTML = '<i class="fas fa-check-circle"></i> Finalizar Venta';
        }
    })
    .catch(error => {
        alert('Error de conexión: ' + error);
        document.getElementById('process_sale').disabled = false;
        document.getElementById('process_sale').innerHTML = '<i class="fas fa-check-circle"></i> Finalizar Venta';
    });
});
</script>

<?php include '../../includes/footer.php'; ?>