<?php
require_once '../../config/database.php';
if (!isset($_SESSION['user_id'])) { header('Location: /modules/auth/login.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'] ?: null;
    $phone = $_POST['phone'] ?: null;
    $address = $_POST['address'] ?: null;

    $stmt = $pdo->prepare("INSERT INTO clients (name, email, phone, address) VALUES (?,?,?,?)");
    $stmt->execute([$name, $email, $phone, $address]);
    
    // 📝 Registrar log de creación de cliente
    $newId = $pdo->lastInsertId();
    registerLog($pdo, 'CREATE', 'clients', $newId, "Cliente creado: $name - Email: $email - Teléfono: $phone");
    
    header('Location: index.php');
    exit;
}

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>
<div class="container mt-4">
    <h2>Nuevo Cliente</h2>
    <form method="POST">
        <div class="mb-3"><label>Nombre *</label><input type="text" name="name" class="form-control" required></div>
        <div class="mb-3"><label>Email</label><input type="email" name="email" class="form-control"></div>
        <div class="mb-3"><label>Teléfono</label><input type="text" name="phone" class="form-control"></div>
        <div class="mb-3"><label>Dirección</label><textarea name="address" class="form-control" rows="2"></textarea></div>
        <button type="submit" class="btn btn-primary">Guardar</button>
        <a href="index.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
<?php include '../../includes/footer.php'; ?>