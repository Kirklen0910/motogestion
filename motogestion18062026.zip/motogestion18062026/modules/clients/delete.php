<?php
require_once '../../config/database.php';
if (!isset($_SESSION['user_id'])) { header('Location: /modules/auth/login.php'); exit; }

$id = $_GET['id'] ?? 0;

// Obtener datos del cliente antes de eliminarlo
$clientData = $pdo->prepare("SELECT name FROM clients WHERE id = ?");
$clientData->execute([$id]);
$client = $clientData->fetch();

if ($client) {
    // 📝 Registrar log de eliminación de cliente
    registerLog($pdo, 'DELETE', 'clients', $id, "Cliente eliminado: {$client['name']}");
}

$stmt = $pdo->prepare("DELETE FROM clients WHERE id = ?");
$stmt->execute([$id]);
header('Location: index.php');
exit;
?>