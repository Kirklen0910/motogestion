<?php
require_once '../../config/database.php';
if (!isset($_SESSION['user_id'])) { header('Location: /modules/auth/login.php'); exit; }

$id = $_GET['id'] ?? 0;
$client = $pdo->prepare("SELECT * FROM clients WHERE id = ?");
$client->execute([$id]);
$client = $client->fetch();

if (!$client) { header('Location: index.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'] ?: null;
    $phone = $_POST['phone'] ?: null;
    $address = $_POST['address'] ?: null;

    $stmt = $pdo->prepare("UPDATE clients SET name=?, email=?, phone=?, address=? WHERE id=?");
    $stmt->execute([$name, $email, $phone, $address, $id]);
    
    // 📝 Registrar log de edición de cliente
    registerLog($pdo, 'UPDATE', 'clients', $id, "Cliente actualizado: $name - Email: $email - Teléfono: $phone");
    
    header('Location: index.php');
    exit;
}

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>
<div class="container mt-4">
    <h2>Editar Cliente</h2>
    <form method="POST">
        <div class="mb-3"><label>Nombre *</label><input type="text" name="name" class="form-control" value="<?= htmlspecialchars($client['name']) ?>" required></div>
        <div class="mb-3"><label>Email</label><input type="email" name="email" class="form-control" value="<?= htmlspecialchars($client['email']) ?>"></div>
        <div class="mb-3"><label>Teléfono</label><input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($client['phone']) ?>"></div>
        <div class="mb-3"><label>Dirección</label><textarea name="address" class="form-control" rows="2"><?= htmlspecialchars($client['address']) ?></textarea></div>
        <button type="submit" class="btn btn-primary">Actualizar</button>
        <a href="index.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
<?php include '../../includes/footer.php'; ?>