<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: /modules/auth/login.php');
    exit;
}

$role = $_SESSION['role'] ?? 'seller';
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'];

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-12">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h3><i class="fas fa-chart-line"></i> Panel de Reportes</h3>
                    <small><i class="fas fa-user-check"></i> Bienvenido <?= htmlspecialchars($fullname) ?> - Rol: <span class="badge bg-light text-dark"><?= ucfirst($role) ?></span></small>
                </div>
                <div class="card-body">
                    
                    <div class="row">
                        
                        <!-- ========== REPORTES DE VENTAS ========== -->
                        <?php if (in_array($role, ['seller', 'cashier', 'admin', 'superadmin'])): ?>
                            <div class="col-md-6 col-lg-4 mb-4">
                                <div class="card h-100 border-primary shadow-sm">
                                    <div class="card-header bg-primary text-white">
                                        <i class="fas fa-shopping-cart"></i> Reportes de Ventas
                                    </div>
                                    <div class="card-body">
                                        <div class="d-grid gap-2">
                                            <a href="sales_report.php" class="btn btn-outline-primary text-start">
                                                <i class="fas fa-chart-line"></i> Reporte General de Ventas
                                            </a>
                                            <a href="daily_sales.php" class="btn btn-outline-primary text-start">
                                                <i class="fas fa-calendar-day"></i> Ventas del Día
                                            </a>
                                            <a href="monthly_sales.php" class="btn btn-outline-primary text-start">
                                                <i class="fas fa-calendar-alt"></i> Ventas del Mes
                                            </a>
                                            <a href="top_products.php" class="btn btn-outline-primary text-start">
                                                <i class="fas fa-trophy"></i> Productos Más Vendidos
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <!-- ========== REPORTES DE INVENTARIO ========== -->
                        <?php if (in_array($role, ['inventory', 'admin', 'superadmin'])): ?>
                            <div class="col-md-6 col-lg-4 mb-4">
                                <div class="card h-100 border-success shadow-sm">
                                    <div class="card-header bg-success text-white">
                                        <i class="fas fa-boxes"></i> Reportes de Inventario
                                    </div>
                                    <div class="card-body">
                                        <div class="d-grid gap-2">
                                            <a href="inventory_report.php" class="btn btn-outline-success text-start">
                                                <i class="fas fa-clipboard-list"></i> Inventario General
                                            </a>
                                            <a href="low_stock_report.php" class="btn btn-outline-success text-start">
                                                <i class="fas fa-exclamation-triangle"></i> Productos con Stock Bajo
                                            </a>
                                            <a href="out_of_stock.php" class="btn btn-outline-success text-start">
                                                <i class="fas fa-ban"></i> Productos Agotados
                                            </a>
                                            <a href="movements_report.php" class="btn btn-outline-success text-start">
                                                <i class="fas fa-exchange-alt"></i> Movimientos de Inventario
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <!-- ========== REPORTES FINANCIEROS ========== -->
                        <?php if (in_array($role, ['finance', 'admin', 'superadmin'])): ?>
                            <div class="col-md-6 col-lg-4 mb-4">
                                <div class="card h-100 border-warning shadow-sm">
                                    <div class="card-header bg-warning text-dark">
                                        <i class="fas fa-coins"></i> Reportes Financieros
                                    </div>
                                    <div class="card-body">
                                        <div class="d-grid gap-2">
                                            <a href="profit_report.php" class="btn btn-outline-warning text-start">
                                                <i class="fas fa-chart-line"></i> Ganancias por Período
                                            </a>
                                            <a href="daily_profit.php" class="btn btn-outline-warning text-start">
                                                <i class="fas fa-calendar-day"></i> Ganancias del Día
                                            </a>
                                            <a href="monthly_profit.php" class="btn btn-outline-warning text-start">
                                                <i class="fas fa-calendar-alt"></i> Ganancias del Mes
                                            </a>
                                            <a href="payment_report.php" class="btn btn-outline-warning text-start">
                                                <i class="fas fa-credit-card"></i> Reporte de Pagos
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <!-- ========== REPORTES DE CLIENTES ========== -->
                        <?php if (in_array($role, ['seller', 'admin', 'superadmin'])): ?>
                            <div class="col-md-6 col-lg-4 mb-4">
                                <div class="card h-100 border-info shadow-sm">
                                    <div class="card-header bg-info text-white">
                                        <i class="fas fa-users"></i> Reportes de Clientes
                                    </div>
                                    <div class="card-body">
                                        <div class="d-grid gap-2">
                                            <a href="top_clients.php" class="btn btn-outline-info text-start">
                                                <i class="fas fa-trophy"></i> Mejores Clientes
                                            </a>
                                            <a href="client_history.php" class="btn btn-outline-info text-start">
                                                <i class="fas fa-history"></i> Historial por Cliente
                                            </a>
                                            <a href="inactive_clients.php" class="btn btn-outline-info text-start">
                                                <i class="fas fa-user-slash"></i> Clientes Inactivos
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <!-- ========== REPORTES DE PROVEEDORES ========== -->
                        <?php if (in_array($role, ['admin', 'superadmin'])): ?>
                            <div class="col-md-6 col-lg-4 mb-4">
                                <div class="card h-100 border-secondary shadow-sm">
                                    <div class="card-header bg-secondary text-white">
                                        <i class="fas fa-truck"></i> Reportes de Proveedores
                                    </div>
                                    <div class="card-body">
                                        <div class="d-grid gap-2">
                                            <a href="suppliers_report.php" class="btn btn-outline-secondary text-start">
                                                <i class="fas fa-list"></i> Listado de Proveedores
                                            </a>
                                            <a href="purchases_report.php" class="btn btn-outline-secondary text-start">
                                                <i class="fas fa-shopping-cart"></i> Compras por Proveedor
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                    </div>
                    
                    <!-- Resumen rápido según el rol -->
                    <div class="row mt-4">
                        <div class="col-12">
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i> 
                                <strong>Resumen de accesos según tu rol (<?= ucfirst($role) ?>):</strong>
                                <ul class="mt-2 mb-0">
                                    <?php if (in_array($role, ['seller', 'cashier', 'admin', 'superadmin'])): ?>
                                        <li><i class="fas fa-shopping-cart text-success"></i> Reportes de Ventas</li>
                                    <?php endif; ?>
                                    <?php if (in_array($role, ['inventory', 'admin', 'superadmin'])): ?>
                                        <li><i class="fas fa-boxes text-info"></i> Reportes de Inventario</li>
                                    <?php endif; ?>
                                    <?php if (in_array($role, ['finance', 'admin', 'superadmin'])): ?>
                                        <li><i class="fas fa-coins text-warning"></i> Reportes Financieros</li>
                                    <?php endif; ?>
                                    <?php if (in_array($role, ['seller', 'admin', 'superadmin'])): ?>
                                        <li><i class="fas fa-users text-primary"></i> Reportes de Clientes</li>
                                    <?php endif; ?>
                                    <?php if (in_array($role, ['admin', 'superadmin'])): ?>
                                        <li><i class="fas fa-truck text-secondary"></i> Reportes de Proveedores</li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Enlaces rápidos -->
                    <div class="row mt-3">
                        <div class="col-12">
                            <div class="alert alert-success">
                                <i class="fas fa-download"></i>
                                <strong>Exportar Reportes:</strong>
                                Todos los reportes se pueden imprimir usando el botón <i class="fas fa-print"></i> <strong>Imprimir</strong> o guardar como PDF desde el navegador.
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>