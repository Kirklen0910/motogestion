<?php
require_once '../../config/database.php';
if (!isset($_SESSION['user_id'])) { header('Location: /modules/auth/login.php'); exit; }

$id = $_GET['id'] ?? 0;
$supplier = $pdo->prepare("SELECT * FROM suppliers WHERE id = ?");
$supplier->execute([$id]);
$supplier = $supplier->fetch();

if (!$supplier) { header('Location: index.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $contact = $_POST['contact'] ?: null;
    $phone = $_POST['phone'] ?: null;

    $stmt = $pdo->prepare("UPDATE suppliers SET name=?, contact=?, phone=? WHERE id=?");
    $stmt->execute([$name, $contact, $phone, $id]);
    
    // 📝 Registrar log de edición de proveedor
    registerLog($pdo, 'UPDATE', 'suppliers', $id, "Proveedor actualizado: $name - Contacto: $contact - Teléfono: $phone");
    
    header('Location: index.php');
    exit;
}

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>
<div class="container mt-4">
    <h2>Editar Proveedor</h2>
    <form method="POST">
        <div class="mb-3"><label>Nombre *</label><input type="text" name="name" class="form-control" value="<?= htmlspecialchars($supplier['name']) ?>" required></div>
        <div class="mb-3"><label>Contacto</label><input type="text" name="contact" class="form-control" value="<?= htmlspecialchars($supplier['contact']) ?>"></div>
        <div class="mb-3"><label>Teléfono</label><input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($supplier['phone']) ?>"></div>
        <button type="submit" class="btn btn-primary">Actualizar</button>
        <a href="index.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
<?php include '../../includes/footer.php'; ?>