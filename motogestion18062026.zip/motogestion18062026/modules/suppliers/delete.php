<?php
require_once '../../config/database.php';
if (!isset($_SESSION['user_id'])) { header('Location: /modules/auth/login.php'); exit; }

$id = $_GET['id'] ?? 0;

// Obtener datos del proveedor antes de eliminarlo
$supplierData = $pdo->prepare("SELECT name FROM suppliers WHERE id = ?");
$supplierData->execute([$id]);
$supplier = $supplierData->fetch();

if ($supplier) {
    // 📝 Registrar log de eliminación de proveedor
    registerLog($pdo, 'DELETE', 'suppliers', $id, "Proveedor eliminado: {$supplier['name']}");
}

$stmt = $pdo->prepare("DELETE FROM suppliers WHERE id = ?");
$stmt->execute([$id]);
header('Location: index.php');
exit;
?>