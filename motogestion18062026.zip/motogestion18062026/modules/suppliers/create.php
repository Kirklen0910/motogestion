<?php
require_once '../../config/database.php';
if (!isset($_SESSION['user_id'])) { header('Location: /modules/auth/login.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $contact = $_POST['contact'] ?: null;
    $phone = $_POST['phone'] ?: null;

    $stmt = $pdo->prepare("INSERT INTO suppliers (name, contact, phone) VALUES (?,?,?)");
    $stmt->execute([$name, $contact, $phone]);
    
    // 📝 Registrar log de creación de proveedor
    $newId = $pdo->lastInsertId();
    registerLog($pdo, 'CREATE', 'suppliers', $newId, "Proveedor creado: $name - Contacto: $contact - Teléfono: $phone");
    
    header('Location: index.php');
    exit;
}

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>
<div class="container mt-4">
    <h2>Nuevo Proveedor</h2>
    <form method="POST">
        <div class="mb-3"><label>Nombre *</label><input type="text" name="name" class="form-control" required></div>
        <div class="mb-3"><label>Contacto</label><input type="text" name="contact" class="form-control"></div>
        <div class="mb-3"><label>Teléfono</label><input type="text" name="phone" class="form-control"></div>
        <button type="submit" class="btn btn-primary">Guardar</button>
        <a href="index.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
<?php include '../../includes/footer.php'; ?>