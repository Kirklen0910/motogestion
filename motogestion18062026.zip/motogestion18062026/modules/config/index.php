<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) { 
    header('Location: /modules/auth/login.php'); 
    exit; 
}

$role = $_SESSION['role'] ?? 'seller';

// ===== REDIRECCIÓN SEGÚN ROL =====
// SUPERADMIN y ADMIN → Empresa
if (in_array($role, ['superadmin', 'admin'])) {
    header('Location: empresa.php');
    exit;
}

// FINANCE → Impuestos
if ($role == 'finance') {
    header('Location: impuestos.php');
    exit;
}

// INVENTORY → Preferencias
if ($role == 'inventory') {
    header('Location: preferencias.php');
    exit;
}

// VENDEDOR y CAJERO → Perfil
if (in_array($role, ['seller', 'cashier'])) {
    header('Location: perfil.php');
    exit;
}

// Si nada coincide, ir al dashboard
header('Location: /modules/dashboard/index.php');
exit;
?>